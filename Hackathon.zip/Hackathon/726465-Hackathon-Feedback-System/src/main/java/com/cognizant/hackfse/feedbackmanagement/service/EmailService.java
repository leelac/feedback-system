package com.cognizant.hackfse.feedbackmanagement.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.client.EmailClient;
import com.cognizant.hackfse.feedbackmanagement.entity.EmployeeEvent;
import com.cognizant.hackfse.feedbackmanagement.entity.Event;
import com.cognizant.hackfse.feedbackmanagement.model.Email;
import com.cognizant.hackfse.feedbackmanagement.repository.EventRepository;

@Service
public class EmailService {
	
	@Autowired
	private EventRepository eventRepository;
	
	@Autowired
	EmailClient emailClient;
	
	public void sendEmail(String eventId, String employeeId, String emailType) {
		EmployeeEvent employeeEvent = new EmployeeEvent();
		employeeEvent.setEmployeeID(employeeId);
		employeeEvent.setEventID(eventId);
		
		Event event = eventRepository.findByEmployeeEvent(employeeEvent);
		
		Map<String, String> additionalOptions = new HashMap<>();
		additionalOptions.put("lastName", event.getEmployeeName());
		additionalOptions.put("eventName", event.getEventName());
		additionalOptions.put("beneficiaryName", event.getBeneficiaryName());
		additionalOptions.put("eventDate", event.getEventDate());
		String details = String.format("%s-%s-%s", event.getEmployeeEvent().getEmployeeID(), event.getEmployeeEvent().getEventID(), event.getEventDate());
		additionalOptions.put("encodedDetails", Base64.getEncoder().encodeToString(details.getBytes()));
		
		Email email = Email.builder()
				.emailType(emailType)
				.emailAddress("sivaleela.chamarthi@gmail.com")
				.options(additionalOptions)
				.build();
		emailClient.sendEmail(email);
	}

}
