package com.cognizant.hackfse.feedbackmanagement.service;

import java.util.Base64;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.entity.EmployeeEvent;
import com.cognizant.hackfse.feedbackmanagement.entity.Event;
import com.cognizant.hackfse.feedbackmanagement.exceptions.FeedbackException;
import com.cognizant.hackfse.feedbackmanagement.model.Feedback;
import com.cognizant.hackfse.feedbackmanagement.repository.EventRepository;

@Service
public class FeedbackService {
	
	@Autowired
	private EventRepository eventRepository;
	
	public String submitFeedback(Feedback feedback) throws FeedbackException {
		
		String detailsDecoded = new String(Base64.getDecoder().decode(feedback.getDetails()));
		
		String[] splittedDecodedDetails = detailsDecoded.split("\\-", 3);
		
		if(splittedDecodedDetails.length != 3) {
			throw new FeedbackException("error.details.invalid");
		}
		
		EmployeeEvent employeeEvent = new EmployeeEvent();
		employeeEvent.setEmployeeID(splittedDecodedDetails[0]);
		employeeEvent.setEventID(splittedDecodedDetails[1]);
		
		Event event = eventRepository.findByEmployeeEventAndEventDateAndVolunteerStatus(employeeEvent, splittedDecodedDetails[2], feedback.getType());
		
		if(event == null) {
			throw new FeedbackException("error.data.notFound");
		}
		
		event.setFeedbackRating(feedback.getRating());
		event.setFeedbackDetails(String.format("%s. %s", feedback.getLikeActivity(), feedback.getImprovedActivity()));
		
		eventRepository.save(event);
		
		return generateRandomId();
	}

	private String generateRandomId() {
		return UUID.randomUUID().toString();
	}

}
