package com.cognizant.hackfse.batch.reader;

import java.io.FileInputStream;
import java.io.PushbackInputStream;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.excel.poi.PoiItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;

import com.cognizant.hackfse.batch.configuration.VolunteerStatus;
import com.cognizant.hackfse.batch.entity.Event;
import com.cognizant.hackfse.batch.rowmappers.VolunteerRowMapper;

@Configuration
public class UnattendedItemReader {
	
	@Value("${file.path.unattended}")
	private String filePath;
	

	@Bean
	public ItemReader<Event> reader() {
		
		PoiItemReader<Event> reader = new PoiItemReader<>();
		try {
			PushbackInputStream pushbackInputStream = new PushbackInputStream(new FileInputStream(filePath));
			reader.setLinesToSkip(1);
			reader.setResource(new InputStreamResource(pushbackInputStream));
			reader.setRowMapper(new VolunteerRowMapper(VolunteerStatus.UNATTENDED.toString()));
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return reader;
	}

}
