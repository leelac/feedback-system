package com.cognizant.hackfse.feedbackmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cognizant.hackfse.feedbackmanagement.entity.EmployeeEvent;
import com.cognizant.hackfse.feedbackmanagement.entity.Event;

public interface EventRepository extends CrudRepository<Event, Long> {

	Event findByEmployeeEventAndEventDateAndVolunteerStatus(EmployeeEvent employeeEvent, String eventDate,
			String volunteerStatus);

	Event findByEmployeeEvent(EmployeeEvent employeeEvent);

	@Query(value = "select * from event where eventID = ?1", nativeQuery = true)
	List<Event> findByEventId(String eventId);

	List<Event> findByBeneficiaryNameAndEventDate(String beneficiaryName, String eventDate);

}
