package com.cognizant.hackfse.uaa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "userinformation")
public class User {

	@Id
	@Column(name = "UserID")
	private int userID;

	@Column(name = "UserName")
	private String userName;

	@Column(name = "Email")
	private String email;

	@Column(name = "Password")
	private String password;

	@Column(name = "BusinessUnit")
	private String businessUnit;

	@Column(name = "IsActive")
	private int isActive;

    
    @OneToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "roleID", nullable = false)
	private Role role;

}
