import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

import { AddressesService } from '../../services/addresses.service';
import { BeneficiaryService } from '../../services/beneficiary.service';
import { EventService } from '../../services/event.service';

@Component({
  selector: 'app-address-selector',
  templateUrl: './address-selector.component.html',
  styleUrls: ['./address-selector.component.scss']
})
export class AddressSelectorComponent implements OnInit {

  countries: any = [];
  cities: any = [];
  beneficiaries: any = [];
  events: any = [];

  selectedCountry: String;
  selectedCity: String;
  selectedBeneficiary: String;
  selectedEvent: String;

  @Output() refreshDataEvent = new EventEmitter<any>();

  constructor(private router: Router, private addressesService: AddressesService, private beneficiaryService: BeneficiaryService, private eventService: EventService) { }

  ngOnInit() {
    this.addressesService.getCountries().subscribe(response => {
       this.countries = response.data.countries;
       console.log(JSON.stringify(this.countries));        
    });
 }

 populateCities(countrySelected: any) {
   console.log("Country selected: "+ countrySelected);
   this.selectedCountry = countrySelected;
   this.addressesService.getCities(countrySelected).subscribe(response => {
     this.cities = response.data.cities;
     console.log(JSON.stringify(this.cities));        
   });
 }

 populateBeneficiaries(citySelected: any) {
  console.log("City selected: "+ citySelected);
  this.selectedCity = citySelected;
  this.beneficiaryService.getBeneficiaries(citySelected).subscribe(response => {
    this.beneficiaries = response.data.beneficiaries;
    console.log(JSON.stringify(this.beneficiaries));        
  });
 }

 populateEvents(beneficiarySelected: any) {
  console.log("City selected: "+ this.selectedCity + " Beneficiary selected: "+ beneficiarySelected);
  this.selectedBeneficiary = beneficiarySelected;
  this.eventService.getEvents(this.selectedCity, beneficiarySelected).subscribe(response => {
    this.events = response.data.events;
    console.log(JSON.stringify(this.events));        
  });
 }

 refreshData(eventSelected: any){
  console.log("Event selected: "+ eventSelected);
  let data = {
    "city":  this.selectedCity,
    "benificiary":  this.selectedBeneficiary,
    "event":  eventSelected
  };
  this.refreshDataEvent.emit(data);
 }

}
