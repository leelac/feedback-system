package com.cognizant.hackfse.batch.upload;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableBatchProcessing
@EnableJpaRepositories(basePackages = "com.cognizant.hackfse.batch")
@EnableScheduling
@ComponentScan("com.cognizant.hackfse.batch")
@EntityScan("com.cognizant.hackfse.batch")
@EnableFeignClients("com.cognizant.hackfse.batch")
public class UploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadApplication.class, args);
	}

}
