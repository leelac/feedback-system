package com.cognizant.hackfse.resource;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.service.EmailService;

import lombok.extern.slf4j.Slf4j;

@Path("/email")
@Produces("application/json")
@Consumes("application/json")
@Slf4j
public class Email {

	@Autowired
	EmailService emailService;

	@GET
	public Response sendFeedbackEmail() {
		try {
			log.info("email end point!!");
			com.cognizant.hackfse.model.Email email = new com.cognizant.hackfse.model.Email();
			email.setEmailAddress("sivaleela.c@cognizant.com");
			Map<String, String> options = new HashMap<>();
			options.put("lastName", "Sivaleela");
			options.put("eventName", "Event1");
			options.put("beneficiaryName", "BeneficiaryName");
			options.put("eventDate", "10/03/2019");
			String details = String.format("%s-%s-%s", "310077", "BeneficiaryName", "10/03/2019");
			options.put("encodedDetails", Base64.getEncoder().encodeToString(details.getBytes()));
			email.setOptions(options);
			emailService.sendEmail(email);
		} catch (MessagingException e) {
			return Response.serverError().build();
		}

		return Response.ok().build();
	}

	@POST
	public Response sendEmail(com.cognizant.hackfse.model.Email email) {
		try {
			log.info("email end point!!");
			emailService.sendEmail(email);
		} catch (MessagingException e) {
			return Response.serverError().build();
		}
		return Response.noContent().build();
	}

}
