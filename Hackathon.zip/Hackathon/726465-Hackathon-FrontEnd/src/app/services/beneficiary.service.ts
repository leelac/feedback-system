import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RestfulResponse } from '../models/restful-response.model';

@Injectable({
  providedIn: 'root'
})
export class BeneficiaryService {
  private apiUrl = 'http://localhost:9092/benificiaries';
  
  constructor(private http:HttpClient) { }

  public getBeneficiaries(citySelected: any){
    return this.http.get<RestfulResponse>(this.apiUrl, {
      params: {
        city: citySelected,
        role: "ADMIN"
      }
    });
  }
}
