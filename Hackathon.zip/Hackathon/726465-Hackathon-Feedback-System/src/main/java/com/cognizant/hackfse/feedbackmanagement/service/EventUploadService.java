package com.cognizant.hackfse.feedbackmanagement.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class EventUploadService {
	
	public boolean uploadEvent(MultipartFile eventFile) {
		
		
		return false;
		
	}
	

}
