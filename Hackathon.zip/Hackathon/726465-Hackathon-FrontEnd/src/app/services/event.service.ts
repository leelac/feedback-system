import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RestfulResponse } from '../models/restful-response.model';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private apiUrl = 'http://localhost:9092/benificiaries';
  
  constructor(private http:HttpClient) { }

  public getEvents(citySelected: any, beneficiarySelected: any){
    return this.http.get<RestfulResponse>(this.apiUrl+"/events", {
      params: {
        city: citySelected,
        beneficiary: beneficiarySelected,
        role: "ADMIN"
      }
    });
  }
}
