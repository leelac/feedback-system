import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RestfulResponse } from '../models/restful-response.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeeventService {
  private apiUrl = 'http://localhost:9092/employee-events';
  
  constructor(private http:HttpClient) { }

  public getEmployeeEvents(citySelected: any, beneficiarySelected: any, eventSelected: any){
    return this.http.get<RestfulResponse>(this.apiUrl, {
      params: {
        city: citySelected,
        beneficiary: beneficiarySelected,
        event: eventSelected,
        role: "ADMIN"
      }
    });
  }
}
