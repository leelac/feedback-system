package com.cognizant.hackfse.feedbackmanagement.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.rest.Payload;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.EmailService;

@Path("/send-email")
@Produces("application/json")
public class EmailController {
	
	@Autowired
	private EmailService emailService;

	@GET
	public Response sendEmail(@QueryParam("eventId") String eventId, @QueryParam("employeeId") String employeeId, @QueryParam("emailType") String emailType){
		emailService.sendEmail(eventId, employeeId, emailType);

		Payload payload = new Payload();
		payload.put("emailSent", true);

		return new RestfulResponse().ok(payload);
	}

}
