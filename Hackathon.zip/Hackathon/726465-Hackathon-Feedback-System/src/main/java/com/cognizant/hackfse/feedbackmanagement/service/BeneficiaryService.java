package com.cognizant.hackfse.feedbackmanagement.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import javax.ws.rs.BadRequestException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.entity.EventSummary;
import com.cognizant.hackfse.feedbackmanagement.repository.EventSummaryRepository;
import com.cognizant.hackfse.feedbackmanagement.service.AddressesService.Roles;

@Service
public class BeneficiaryService {

	@Autowired
	private EventSummaryRepository eventSummaryRepository;

	public List<String> getBeneficiaries(String city, String role, String employeeId) {

		List<EventSummary> eventSummaries = null;

		if (Roles.ADMIN.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByVenueAddressOrderByBeneficiaryNameAsc(city);
		} else if (Roles.PMO.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndPmoIDOrderByBeneficiaryNameAsc(city,
					employeeId);
		} else if (Roles.POC.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndPocIDOrderByBeneficiaryNameAsc(city,
					employeeId);
		}

		if (eventSummaries == null) {
			throw new BadRequestException("Unable to fetch the details");
		}

		return eventSummaries.stream().map(EventSummary::getBeneficiaryName).distinct().collect(Collectors.toList());
	}

	public List<String> getEventsForBeneficiaries(String city, String role, String employeeId, String beneficiary) {

		List<EventSummary> eventSummaries = null;

		if (Roles.ADMIN.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameOrderByEventDateAsc(city,
					beneficiary);
		} else if (Roles.PMO.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository
					.findByVenueAddressAndBeneficiaryNameAndPmoIDOrderByEventDateAsc(city, beneficiary, employeeId);
		} else if (Roles.POC.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository
					.findByVenueAddressAndBeneficiaryNameAndPocIDOrderByEventDateAsc(city, beneficiary, employeeId);
		}

		if (eventSummaries == null) {
			throw new BadRequestException("Unable to fetch the details");
		}

		return eventSummaries.stream().map(EventSummary::getEventName).distinct().collect(Collectors.toList());
	}

}
