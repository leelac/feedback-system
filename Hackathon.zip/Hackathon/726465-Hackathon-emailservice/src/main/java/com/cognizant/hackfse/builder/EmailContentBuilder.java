package com.cognizant.hackfse.builder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.cognizant.hackfse.model.Email;

@Service
public class EmailContentBuilder {

	private TemplateEngine templateEngine;

	@Value("${hackfse.feedback.redirect.url:http://localhost:4200/feedback}")
	private String feedbackRedirectUrl;

	@Autowired
	public EmailContentBuilder(TemplateEngine templateEngine) {
		this.templateEngine = templateEngine;
	}

	public String build(Email email) {
		Context context = new Context();
		if (email.getOptions() != null) {
			context.setVariable("lastName", email.getOptions().get("lastName"));
			context.setVariable("eventName", email.getOptions().get("eventName"));
			context.setVariable("beneficiaryName", email.getOptions().get("beneficiaryName"));
			context.setVariable("eventDate", email.getOptions().get("eventDate"));
			context.setVariable("baseUrl",
					feedbackRedirectUrl + "?details=" + email.getOptions().get("encodedDetails"));
		}
		return templateEngine.process(EmailType.getEmailTemplate(email.getEmailType()), context);
	}

	enum EmailType {
		REGISTERED_PARTICIPATED("FeedbackRegisteredParticipated", "REGISTERED"),
		REGISTERED_NOT_PARTICIPATED("FeedbackRegisteredNotParticipated", "UNATTENDED"),
		UN_REGISTERED("FeedbackUnRegistered", "UNREGISTERED"), 
		REPLY_EMAIL("FeedbackReplyEmail", "REPLY"),
		UN_KNOW(null, null);

		private String template;
		private String type;

		public String getTemplate() {
			return template;
		}

		public String getType() {
			return type;
		}

		EmailType(String template, String type) {
			this.template = template;
			this.type = type;
		}

		public static String getEmailTemplate(String type) {
			String emailTemplate = EmailType.UN_KNOW.getTemplate();
			for (EmailType emailType : EmailType.values()) {
				if (type.equalsIgnoreCase(emailType.getType())) {
					emailTemplate = emailType.getTemplate();
					break;
				}
			}
			return emailTemplate;
		}
	}
}
