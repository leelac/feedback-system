package com.cognizant.hackfse.feedbackmanagement.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ws.rs.BadRequestException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.entity.Event;
import com.cognizant.hackfse.feedbackmanagement.entity.EventSummary;
import com.cognizant.hackfse.feedbackmanagement.model.Dashboard;
import com.cognizant.hackfse.feedbackmanagement.model.Report;
import com.cognizant.hackfse.feedbackmanagement.model.request.DashboardReportRequest;
import com.cognizant.hackfse.feedbackmanagement.model.request.DashboardRequest;
import com.cognizant.hackfse.feedbackmanagement.repository.EventRepository;
import com.cognizant.hackfse.feedbackmanagement.repository.EventSummaryRepository;
import com.cognizant.hackfse.feedbackmanagement.service.AddressesService.Roles;

@Service
public class DashboardService {

	@Autowired
	private EventSummaryRepository eventSummaryRepository;

	@Autowired
	private EventRepository eventRepository;

	public Dashboard fetchDashboardDetails(DashboardRequest dashboardRequest) {

		List<EventSummary> eventSummaries = null;

		if (Roles.ADMIN.name().equalsIgnoreCase(dashboardRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventName(
					dashboardRequest.getCity(), dashboardRequest.getBeneficiary(), dashboardRequest.getEvent());
		} else if (Roles.PMO.name().equalsIgnoreCase(dashboardRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventNameAndPmoID(
					dashboardRequest.getCity(), dashboardRequest.getBeneficiary(), dashboardRequest.getEmployeeId(),
					dashboardRequest.getEvent());
		} else if (Roles.POC.name().equalsIgnoreCase(dashboardRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventNameAndPocID(
					dashboardRequest.getCity(), dashboardRequest.getBeneficiary(), dashboardRequest.getEmployeeId(),
					dashboardRequest.getEvent());
		}

		if (eventSummaries == null || eventSummaries.size() > 1) {
			throw new BadRequestException("Unable to fetch the details");
		}

		EventSummary eventSummary = eventSummaries.get(0);

		List<Event> events = eventRepository.findByBeneficiaryNameAndEventDate(eventSummary.getBeneficiaryName(),
				eventSummary.getEventDate());

		List<Event> feedbackProvidedEvents = events.stream().filter(event -> event.getFeedbackRating() != null)
				.collect(Collectors.toList());

		Dashboard dashboard = new Dashboard();
		dashboard.setEmployeeCount(events.size());
		dashboard.setFeedbackProvidedCount(feedbackProvidedEvents.size());

		List<Integer> ratings = feedbackProvidedEvents.stream()
				.map(event -> Integer.parseInt(event.getFeedbackRating())).collect(Collectors.toList());

		OptionalDouble average = ratings.stream().mapToInt(a -> a).average();

		dashboard.setAverageScore(average.isPresent() ? average.getAsDouble() : 0);

		return dashboard;
	}

	public List<Report> fetchDashboardReport(DashboardReportRequest dashboardReportRequest) {

		List<EventSummary> eventSummaries = eventSummaryRepository
				.findByVenueAddressAndBeneficiaryNameOrderByEventDateAsc(dashboardReportRequest.getCity(),
						dashboardReportRequest.getBeneficiary());

		if (eventSummaries == null) {
			throw new BadRequestException("Unable to fetch the details");
		}

		List<Event> events = eventSummaries.stream()
				.flatMap(eventSumm -> filterEvents(eventSumm, dashboardReportRequest)).collect(Collectors.toList());

		List<Report> reports = reportsFor(events);

		List<Report> finalReports = new ArrayList<>();

		List<String> labels = reports.stream().map(repo -> repo.getLabel()).distinct().collect(Collectors.toList());

		labels.forEach(lab -> {
			List<Report> labelFilteredReports = reports.stream().filter(rep -> rep.getLabel().equalsIgnoreCase(lab))
					.collect(Collectors.toList());
			List<Double> ratings = labelFilteredReports.stream().map(filRep -> filRep.getValue())
					.collect(Collectors.toList());
			OptionalDouble average = ratings.stream().mapToDouble(a -> a).average();

			Report report = new Report();
			report.setLabel(lab);
			report.setValue(average.isPresent() ? average.getAsDouble() : 0);
			finalReports.add(report);
		});

		return finalReports;
	}


	private List<Report> reportsFor(List<Event> events) {

		DateTimeFormatter eventDateFormatter = DateTimeFormatter.ofPattern("dd-MM-yy");

		return events.stream().map(event -> {
			LocalDate eventDate = LocalDate.parse(event.getEventDate(), eventDateFormatter);
			Report report = new Report();
			report.setLabel(eventDate.getMonth().getDisplayName(TextStyle.FULL, Locale.US));
			report.setValue(Double.parseDouble(event.getFeedbackRating()));
			return report;
		}).collect(Collectors.toList());
	}

	private Stream<Event> filterEvents(EventSummary eventSumm, DashboardReportRequest dashboardReportRequest) {

		List<Event> events = eventRepository.findByEventId(eventSumm.getEventID());

		if (events == null) {
			throw new BadRequestException("Unable to fetch the details");
		}

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		DateTimeFormatter eventDateFormatter = DateTimeFormatter.ofPattern("dd-MM-yy");

		LocalDate startDate = LocalDate.parse(dashboardReportRequest.getStartDate(), formatter);

		LocalDate endDate = LocalDate.parse(dashboardReportRequest.getEndDate(), formatter);

		List<Event> filteredEvents = events.stream().filter(event -> {
			LocalDate eventDate = LocalDate.parse(event.getEventDate(), eventDateFormatter);
			return ((eventDate.isEqual(startDate) || eventDate.isEqual(endDate))
					|| (eventDate.isAfter(startDate) && eventDate.isBefore(endDate)))
					&& event.getFeedbackRating() != null;
		}).distinct().collect(Collectors.toList());

		return filteredEvents.stream();
	}

}
