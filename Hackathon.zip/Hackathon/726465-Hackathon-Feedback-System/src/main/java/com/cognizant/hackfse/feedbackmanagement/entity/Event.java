package com.cognizant.hackfse.feedbackmanagement.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "event")
@DynamicUpdate
public class Event implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private EmployeeEvent employeeEvent;
	
	@Column(name = "BaseLocation")
	private String baseLocation;

	@Column(name = "BeneficiaryName")
	private String beneficiaryName;

	@Column(name = "CouncilName")
	private String councilName;

	@Column(name = "EventName")
	private String eventName;

	@Column(name = "EventDescription")
	private String eventDescription;

	@Column(name = "EventDate")
	private String eventDate;

	@Column(name = "EmployeeName")
	private String employeeName;

	@Column(name = "VolunteerHours")
	private String volunteerHours;

	@Column(name = "TravelHours")
	private String travelHours;

	@Column(name = "LivesImpacted")
	private String livesImpacted;

	@Column(name = "BusinessUnit")
	private String businessUnit;

	@Column(name = "Status")
	private String status;

	@Column(name = "IiepCategory")
	private String iiepCategory;

	@Column(name = "VolunteerStatus")
	private String volunteerStatus;

	@Column(name = "FeedbackRating")
	private String feedbackRating;

	@Column(name = "FeedbackDetails")
	private String feedbackDetails;

}
