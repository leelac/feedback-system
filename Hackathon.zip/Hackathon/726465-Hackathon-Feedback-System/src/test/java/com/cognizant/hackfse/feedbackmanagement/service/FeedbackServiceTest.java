package com.cognizant.hackfse.feedbackmanagement.service;

import java.util.Base64;

public class FeedbackServiceTest {
	
	public static void main(String[] args) {
		System.out.println(Base64.getEncoder().encodeToString(String.format("%s-%s-%s", "100000.0", "EVNT00047263", "15-12-18").getBytes()));
	}

}
