package com.cognizant.hackfse.batch.configuration;

public enum VolunteerStatus {
	REGISTERED,
	UNREGISTERED,
	UNATTENDED

}
