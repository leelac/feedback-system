package com.cognizant.hackfse.batch.configuration;

import java.util.Date;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.cognizant.hackfse.batch.entity.EventSummary;
import com.cognizant.hackfse.batch.listener.CustomJobExecutionListener;
import com.cognizant.hackfse.batch.processor.EventSummaryItemProcessor;
import com.cognizant.hackfse.batch.reader.EventSummaryItemReader;
import com.cognizant.hackfse.batch.writer.EventSummaryItemWriter;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class EventSummaryUploadConfiguration {

	

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	CustomJobExecutionListener customJobExecutionListener;

	@Autowired
	EventSummaryItemReader eventSummaryItemReader;

	@Autowired
	EventSummaryItemWriter eventSummaryItemWriter;

	@Autowired
	EventSummaryItemProcessor eventSummaryItemProcessor;
	
	@Autowired
	JobLauncher jobLauncher;

	@Value("${chunk.commitInterval}")
	private int commitInterval;

	@Scheduled(cron = "${cron.schedule.eventSummary}")
	 public void runJob() {
	   log.info("Job Started at :" + new Date());

	   try {
	     JobParameters param =
	         new JobParametersBuilder()
	             .addString("partitionerJob", String.valueOf(System.currentTimeMillis()))
	             .toJobParameters();

	     jobLauncher.run(eventSummaryJob(), param);

	   } catch (JobExecutionAlreadyRunningException
	       | JobRestartException
	       | JobInstanceAlreadyCompleteException
	       | JobParametersInvalidException e) {

	     log.error("Error occurred while launching Job " + e);
	   }
	 }
	
	

	@Bean
	public Job eventSummaryJob() {
		return jobBuilderFactory.get("eventSummaryJob").incrementer(new RunIdIncrementer())
				.listener(customJobExecutionListener).flow(eventSummaryStep()).end().build();
	}

	@Bean
	public Step eventSummaryStep() {
		return stepBuilderFactory.get("eventSummaryStep").<EventSummary, EventSummary>chunk(10)
				.reader(eventSummaryItemReader.eventSummaryReader()).processor(eventSummaryItemProcessor)
				.writer(eventSummaryItemWriter).build();
	}

}