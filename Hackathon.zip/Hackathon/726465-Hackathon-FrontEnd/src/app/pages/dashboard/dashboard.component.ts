import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

import { DashboardService } from '../../services/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dataSource: Object;
  chartConfig: Object;  
  dashboardDetails: Object;
  dashboardDetailsAvailable: boolean;
  addressData: any;

  public minDate: Date = new Date(2018, 10, 1);
  public maxDate: Date = new Date(2019, 9, 30)

  constructor(private dashboardService: DashboardService) {
    this.chartConfig = {
      width: '900',
      height: '400',
      type: 'column2d',
      dataFormat: 'json',
      theme: "ocean",
      bgColor: "#efefef",
  };

  
   }

   ngOnInit() {     
  }

  refreshChart(startDate: any, endDate: any){
    var datePipe = new DatePipe("en-US");

    var formattedStartDate = datePipe.transform(startDate, 'dd-MM-yyyy');
    var formattedEndDate = datePipe.transform(endDate, 'dd-MM-yyyy')
    console.log("Stardate:" + datePipe.transform(startDate, 'dd-MM-yyyy'));

    this.dashboardService.getDashboardReport(this.addressData.city, this.addressData.benificiary, formattedStartDate, formattedEndDate).subscribe(response => {
      console.log(JSON.stringify(response.data.reports)); 
      
      this.dataSource = {
        "chart": {
          "xAxisName": "Month",
          "yAxisName": "Feedback",
          "theme": "fusion",
          "palettecolors":"#81d1ef",
          "usePlotGradientColor": "1",
          "plotGradientColor":"#deeef4",
          "bgColor": "#e6f1f2",
          "bgAlpha": "50",
          "labelDisplay": "rotate",
          "slantLabel": "1",
          "labelFontBold":"1",
          "labelFont": "Arial",
          "baseFont": "Arial",
          "baseFontSize": "14",
          "outCnvBaseFont": "Arial",
          "outCnvBaseFontSize": "14"
        },
        "data": response.data.reports
      };


    });

  }

  refreshData(data) {
    console.log(JSON.stringify(data));
    this.addressData = data;
    this.dashboardService.getDashboardDetails(data.city, data.benificiary, data.event).subscribe(response => {
      this.dashboardDetails = response.data.dashboard;
      this.dashboardDetailsAvailable = true;
      console.log(JSON.stringify(this.dashboardDetails));        
    });

  }

}