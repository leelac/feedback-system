package com.cognizant.hackfse.batch.configuration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.Event;
import com.cognizant.hackfse.batch.listener.CustomJobExecutionListener;
import com.cognizant.hackfse.batch.processor.EventItemProcessor;
import com.cognizant.hackfse.batch.reader.UnregisteredItemReader;
import com.cognizant.hackfse.batch.writer.VolunteerItemWriter;

@Configuration
public class UnregisteredConfiguration {
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired CustomJobExecutionListener customJobExecutionListener;

	@Autowired
	UnregisteredItemReader unregisteredItemReader;
	
	@Autowired
	VolunteerItemWriter volunteerItemWriter;
	
	@Autowired
	EventItemProcessor eventItemProcessor;

	@Value("${chunk.commitInterval}")
	private int commitInterval;
	

	
	@Bean
	public Job unregisteredJob(Step unregisteredStep) {
		return jobBuilderFactory.get("unregisteredJob").incrementer(new RunIdIncrementer()).listener(customJobExecutionListener)
				.flow(unregisteredStep).end().build();
	}

	@Bean
	public Step unregisteredStep() {
		return stepBuilderFactory.get("unregisteredStep").<Event, Event>chunk(10).
				reader(unregisteredItemReader.volunteerReader())
				.processor(eventItemProcessor).writer(volunteerItemWriter).build();
	}


	
}