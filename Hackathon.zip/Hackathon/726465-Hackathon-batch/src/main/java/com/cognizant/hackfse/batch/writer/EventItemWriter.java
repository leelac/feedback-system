package com.cognizant.hackfse.batch.writer;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.Event;
import com.cognizant.hackfse.batch.repository.EventRepository;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class EventItemWriter implements ItemWriter<Event> {

	@Autowired
	EventRepository eventRepository;

	@Override
	public void write(List<? extends Event> events) throws Exception {
		events.stream().map(event -> eventRepository.save(event)).collect(Collectors.toList());

	}

}
