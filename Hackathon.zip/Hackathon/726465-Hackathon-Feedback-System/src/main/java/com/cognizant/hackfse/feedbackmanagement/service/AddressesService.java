package com.cognizant.hackfse.feedbackmanagement.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.entity.EventSummary;
import com.cognizant.hackfse.feedbackmanagement.exceptions.AddressException;
import com.cognizant.hackfse.feedbackmanagement.repository.EventSummaryRepository;

@Service
public class AddressesService {

	@Autowired
	private EventSummaryRepository eventSummaryRepository;

	public List<String> getCountries(String role, String empId) throws AddressException {

		List<EventSummary> eventSummaries = null;

		if (Roles.ADMIN.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findAllByOrderByBaseLocationAsc();
		} else if (Roles.PMO.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByPmoIDOrderByBaseLocationAsc(empId);
		} else if (Roles.POC.name().equalsIgnoreCase(role)) {
			eventSummaries = eventSummaryRepository.findByPocIDOrderByBaseLocationAsc(empId);
		}

		if (eventSummaries == null) {
			throw new AddressException("Unable to fetch the details");
		}

		return eventSummaries.stream().map(EventSummary::getBaseLocation).distinct().collect(Collectors.toList());
	}

	public List<String> getCities(String country) throws AddressException {

		List<EventSummary> eventSummaries = eventSummaryRepository.findByBaseLocationOrderByVenueAddressAsc(country);

		if (eventSummaries == null) {
			throw new AddressException("Unable to fetch the details");
		}

		return eventSummaries.stream().map(EventSummary::getVenueAddress).distinct().collect(Collectors.toList());
	}

	public enum Roles {
		ADMIN, PMO, POC
	}

}
