package com.cognizant.hackfse.feedbackmanagement.controllers;

import java.net.URI;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.exceptions.FeedbackException;
import com.cognizant.hackfse.feedbackmanagement.model.Feedback;
import com.cognizant.hackfse.feedbackmanagement.service.FeedbackService;

@Path("/feedback")
@Produces("application/json")
@Consumes("application/json")
public class FeedbackController {

	@Autowired
	public FeedbackService feedbackService;

	@POST
	public Response submitFeedback(Feedback feedback) throws FeedbackException {
		String feedbackId = feedbackService.submitFeedback(feedback);
		feedback.setId(feedbackId);
		return Response.created(URI.create("/" + feedback.getId())).entity(feedback).build();
	}

}
