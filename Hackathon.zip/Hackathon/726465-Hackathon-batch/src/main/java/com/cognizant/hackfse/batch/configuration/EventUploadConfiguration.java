package com.cognizant.hackfse.batch.configuration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.Event;
import com.cognizant.hackfse.batch.listener.CustomJobExecutionListener;
import com.cognizant.hackfse.batch.processor.EventItemProcessor;
import com.cognizant.hackfse.batch.reader.EventItemReader;
import com.cognizant.hackfse.batch.writer.EventItemWriter;

@Configuration
public class EventUploadConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired CustomJobExecutionListener customJobExecutionListener;

	@Autowired
	EventItemReader eventItemReader;
	
	@Autowired
	EventItemWriter eventItemWriter;
	
	@Autowired
	EventItemProcessor eventItemProcessor;

	@Value("${chunk.commitInterval}")
	private int commitInterval;

	@Bean
	public Job importUserJob(Step step1) {
		return jobBuilderFactory.get("importUserJob").incrementer(new RunIdIncrementer()).listener(customJobExecutionListener)
				.flow(step1).end().build();
	}

	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<Event, Event>chunk(10).reader(eventItemReader.eventReader())
				.processor(eventItemProcessor).writer(eventItemWriter).build();
	}

	

}