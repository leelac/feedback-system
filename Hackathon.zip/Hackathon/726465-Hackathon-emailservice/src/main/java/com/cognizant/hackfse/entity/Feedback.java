package com.cognizant.hackfse.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

import lombok.Data;

public class Feedback {
	
	
	private int templateID;
	
	private String templateName;
	
	private String content;

}
