package com.cognizant.hackfse.feedbackmanagement.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.cognizant.hackfse.feedbackmanagement.model.Violation;

@Provider
public class FeedbackExceptionMapper implements ExceptionMapper<FeedbackException> {

	@Override
	public Response toResponse(FeedbackException exception) {
		Violation violation = new Violation();
		violation.setMessage(exception.getMessage());
		return Response.status(Status.BAD_REQUEST).entity(violation).type(MediaType.APPLICATION_JSON).build();
	}

}
