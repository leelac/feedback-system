package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Country {
	private String name;
}
