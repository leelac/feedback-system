package com.cognizant.hackfse.feedbackmanagement.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "eventSummary")
public class EventSummary implements Serializable{
	
	private static final long serialVersionUID = 1L;
	 
	@Id
	@Column(name="EventID")
	private String eventID;
	
	@Column(name="Month")
	private String month;
	
	@Column(name = "BaseLocation")
	private String baseLocation;
	
	@Column(name = "BeneficiaryName")
	private String beneficiaryName;
	
	@Column(name = "VenueAddress")
	private String venueAddress;
	
	@Column(name = "CouncilName")
	private String councilName;
	
	@Column(name = "Project")
	private String project;
	
	@Column(name = "Category")
	private String category;
	
	@Column(name = "EventName")
	private String eventName;
	
	@Column(name = "EventDescription")
	private String eventDescription;
	
	@Column(name = "EventDate")
	private String eventDate;

	@Column(name = "TotalVolunteers")
	private String totalVolunteers;
	
	@Column(name = "TotalVolunteerHours")
	private String totalVolunteerHours;

	@Column(name = "TotalTravelHours")
	private String totalTravelHours;
	
	@Column(name = "OverallVolunteeringHours")
	private String overallVolunteeringHours;
	
	@Column(name = "LivesImpacted")
	private String livesImpacted;
	
	@Column(name = "ActivityType")
	private String activityType;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "PocId")
	private String pocID;
	
	@Column(name = "PocName")
	private String poName;
	
	@Column(name = "PMOId")
	private String pmoID;
	
	@Column(name = "PMOName")
	private String pmoName;
	
	@Column(name = "PocContactNumber")
	private String pocContactNumber;
	
	
	

}
