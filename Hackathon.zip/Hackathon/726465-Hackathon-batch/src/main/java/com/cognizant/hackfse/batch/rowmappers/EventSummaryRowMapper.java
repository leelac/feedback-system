package com.cognizant.hackfse.batch.rowmappers;

import org.springframework.batch.item.excel.RowMapper;
import org.springframework.batch.item.excel.support.rowset.RowSet;

import com.cognizant.hackfse.batch.entity.EventSummary;

public class EventSummaryRowMapper implements RowMapper<EventSummary> {

	@Override
	public EventSummary mapRow(RowSet eventSummary) throws Exception {
		

		return EventSummary.builder()
				.eventID(eventSummary.getColumnValue(0))
				.month(eventSummary.getColumnValue(1))
				.baseLocation(eventSummary.getColumnValue(2))
				.beneficiaryName(eventSummary.getColumnValue(3))
				.venueAddress(eventSummary.getColumnValue(4))
				.councilName(eventSummary.getColumnValue(5))
				.project(eventSummary.getColumnValue(6))
				.category(eventSummary.getColumnValue(7))
				.eventName(eventSummary.getColumnValue(8))
				.eventDescription(eventSummary.getColumnValue(9))
				.eventDate(eventSummary.getColumnValue(10))
				.totalVolunteers(eventSummary.getColumnValue(11))
				.totalVolunteerHours(eventSummary.getColumnValue(12))
				.totalTravelHours(eventSummary.getColumnValue(13))
				.overallVolunteeringHours(eventSummary.getColumnValue(14))
				.livesImpacted(eventSummary.getColumnValue(15))
				.activityType(eventSummary.getColumnValue(16))
				.status(eventSummary.getColumnValue(17))
				.pocID(eventSummary.getColumnValue(18))
				.poName(eventSummary.getColumnValue(19))
				.pocContactNumber(eventSummary.getColumnValue(20))
				.build();
	}
	

}
