package com.cognizant.hackfse.batch.writer;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.EventSummary;
import com.cognizant.hackfse.batch.repository.EventSummaryRepository;


@Configuration
public class EventSummaryItemWriter implements ItemWriter<EventSummary> {

	@Autowired
	EventSummaryRepository eventSummaryRepository;
	
	@Value("${file.path.eventSummary}")
	private String filePath;

	
	@Override
	public void write(List<? extends EventSummary> items) throws Exception {
		items.stream().map(item -> eventSummaryRepository.save(item)).collect(Collectors.toList());
		new File(filePath).delete();
	}

}
