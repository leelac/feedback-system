package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Event {
	private String name;
}
