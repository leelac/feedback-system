package com.cognizant.hackfse.feedbackmanagement.model.request;

import javax.ws.rs.QueryParam;

import lombok.Data;

@Data
public class DashboardReportRequest {

	@QueryParam("city")
	private String city;

	@QueryParam("beneficiary")
	private String beneficiary;
	
	@QueryParam("startDate")
	private String startDate;
	
	@QueryParam("endDate")
	private String endDate;

}
