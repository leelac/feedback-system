package com.cognizant.hackfse.batch.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.hackfse.batch.model.Email;

@FeignClient(name = "email", url = "${email.url}")
public interface EmailClient {   

    @RequestMapping(method = RequestMethod.POST,consumes = "application/json")
    Email sendEmail(@RequestBody Email email);
}