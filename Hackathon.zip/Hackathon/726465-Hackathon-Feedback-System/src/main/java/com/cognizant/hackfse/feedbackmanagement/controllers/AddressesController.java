package com.cognizant.hackfse.feedbackmanagement.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.exceptions.AddressException;
import com.cognizant.hackfse.feedbackmanagement.model.City;
import com.cognizant.hackfse.feedbackmanagement.model.Country;
import com.cognizant.hackfse.feedbackmanagement.rest.Payload;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.AddressesService;

@Path("/addresses")
@Produces("application/json")
public class AddressesController {

	private AddressesService addressesService;

	@Autowired
	public AddressesController(AddressesService addressesService) {
		this.addressesService = addressesService;
	}

	@GET
	@Path("/countries")
	public Response getCountries(@QueryParam("role") String role, @QueryParam("employeeId") String employeeId)
			throws AddressException {
		List<String> countries = addressesService.getCountries(role, employeeId);

		Payload payload = new Payload();
		payload.put("countries", countriesFor(countries));

		return new RestfulResponse().ok(payload);
	}

	@GET
	@Path("/cities")
	public Response getCities(@QueryParam("country") String country) throws AddressException {
		List<String> cities = addressesService.getCities(country);

		Payload payload = new Payload();
		payload.put("cities", citiesFor(cities));

		return new RestfulResponse().ok(payload);
	}

	private List<Country> countriesFor(List<String> countries) {
		return countries.stream().map(coun -> {
			Country country = new Country();
			country.setName(coun);
			return country;
		}).collect(Collectors.toList());
	}

	private List<City> citiesFor(List<String> cities) {
		return cities.stream().map(ci -> {
			City city = new City();
			city.setName(ci);
			return city;
		}).collect(Collectors.toList());
	}
}
