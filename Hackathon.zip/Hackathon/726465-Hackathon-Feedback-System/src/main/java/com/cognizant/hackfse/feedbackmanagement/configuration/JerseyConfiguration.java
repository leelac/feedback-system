package com.cognizant.hackfse.feedbackmanagement.configuration;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.cognizant.hackfse.feedbackmanagement.controllers.AddressesController;
import com.cognizant.hackfse.feedbackmanagement.controllers.BeneficiaryController;
import com.cognizant.hackfse.feedbackmanagement.controllers.DashboardController;
import com.cognizant.hackfse.feedbackmanagement.controllers.EmailController;
import com.cognizant.hackfse.feedbackmanagement.controllers.EmployeeEventController;
import com.cognizant.hackfse.feedbackmanagement.controllers.FeedbackController;
import com.cognizant.hackfse.feedbackmanagement.controllers.UploadController;
import com.cognizant.hackfse.feedbackmanagement.exceptions.AddressExceptionMapper;
import com.cognizant.hackfse.feedbackmanagement.exceptions.FeedbackExceptionMapper;

@Component
public class JerseyConfiguration extends ResourceConfig {
	
	JerseyConfiguration() {
		register(UploadController.class);
		register(AddressesController.class);
		register(FeedbackController.class);
		register(BeneficiaryController.class);
		register(DashboardController.class);
		register(EmployeeEventController.class);
		register(EmailController.class);
		
		register(FeedbackExceptionMapper.class);
		register(AddressExceptionMapper.class);
	}

}
