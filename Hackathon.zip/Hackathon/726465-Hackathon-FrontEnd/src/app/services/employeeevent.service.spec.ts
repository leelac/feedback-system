import { TestBed } from '@angular/core/testing';

import { EmployeeeventService } from './employeeevent.service';

describe('EmployeeeventService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeeventService = TestBed.get(EmployeeeventService);
    expect(service).toBeTruthy();
  });
});
