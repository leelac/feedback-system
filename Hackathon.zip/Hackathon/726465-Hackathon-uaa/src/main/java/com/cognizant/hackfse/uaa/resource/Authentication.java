package com.cognizant.hackfse.uaa.resource;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.cognizant.hackfse.uaa.model.UserInformation;

@Path("/users")
@Produces("application/json")
@Consumes("application/json")
public class Authentication {
	
	
	@POST
	public Response authenticateUser(@Valid UserInformation userInformation) {
		System.out.println("test!!");
		
		return Response.accepted().build();
		
	}

}
