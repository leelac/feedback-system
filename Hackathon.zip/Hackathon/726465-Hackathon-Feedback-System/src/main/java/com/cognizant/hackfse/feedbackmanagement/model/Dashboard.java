package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Dashboard {
	private Integer employeeCount;
	private Integer feedbackProvidedCount;
	private Double averageScore;
}
