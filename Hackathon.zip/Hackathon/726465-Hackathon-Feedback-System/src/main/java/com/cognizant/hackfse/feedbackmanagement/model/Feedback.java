package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Feedback {
	private String id;
	private String details;
	private String rating;
	private String likeActivity;
	private String improvedActivity;
	private String type;
}
