package com.cognizant.hackfse.feedbackmanagement.controllers;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.model.EmployeeEvent;
import com.cognizant.hackfse.feedbackmanagement.model.request.EmployeeEventRequest;
import com.cognizant.hackfse.feedbackmanagement.rest.Payload;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.EmployeeEventService;

@Path("/employee-events")
@Produces("application/json")
public class EmployeeEventController {
	
	@Autowired
	private EmployeeEventService employeeEventService;
	
	@GET
	public Response getEmployeeEvents(@BeanParam EmployeeEventRequest employeeEventRequest) {
		List<EmployeeEvent> employeeEvents = employeeEventService.fetchEmployeeEventDetails(employeeEventRequest);

		Payload payload = new Payload();
		payload.put("employeeEvents", employeeEvents);

		return new RestfulResponse().ok(payload);
	}

}
