package com.cognizant.hackfse.configuration;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.cognizant.hackfse.resource.Email;

@Component
public class JerseyConfiguration extends ResourceConfig {

	public JerseyConfiguration() {
		register(Email.class);
	}

}
