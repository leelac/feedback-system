package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Violation {
	private String message;
}
