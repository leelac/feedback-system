package com.cognizant.hackfse.batch.reader;

import java.io.FileInputStream;
import java.io.PushbackInputStream;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.excel.poi.PoiItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;

import com.cognizant.hackfse.batch.entity.EventSummary;
import com.cognizant.hackfse.batch.rowmappers.EventSummaryRowMapper;

@Configuration
public class EventSummaryItemReader {
	
	@Value("${file.path.eventSummary}")
	private String filePath;

	@Bean
	public ItemReader<EventSummary> eventSummaryReader() {
		
		PoiItemReader<EventSummary> reader = new PoiItemReader<>();
		try {
			PushbackInputStream pushbackInputStream = new PushbackInputStream(new FileInputStream(filePath));
			reader.setLinesToSkip(1);
			reader.setResource(new InputStreamResource(pushbackInputStream));
			reader.setRowMapper(new EventSummaryRowMapper());
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return reader;
	}

}
