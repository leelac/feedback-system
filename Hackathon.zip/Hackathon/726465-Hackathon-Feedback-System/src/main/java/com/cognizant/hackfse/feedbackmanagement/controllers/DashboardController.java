package com.cognizant.hackfse.feedbackmanagement.controllers;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.model.Dashboard;
import com.cognizant.hackfse.feedbackmanagement.model.Report;
import com.cognizant.hackfse.feedbackmanagement.model.request.DashboardReportRequest;
import com.cognizant.hackfse.feedbackmanagement.model.request.DashboardRequest;
import com.cognizant.hackfse.feedbackmanagement.rest.Payload;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.DashboardService;

@Path("/dashboard")
@Produces("application/json")
public class DashboardController {

	@Autowired
	private DashboardService dashboardService;

	@GET
	public Response getDashboardDetails(@BeanParam DashboardRequest dashboardRequest){
		Dashboard dashboard = dashboardService.fetchDashboardDetails(dashboardRequest);

		Payload payload = new Payload();
		payload.put("dashboard", dashboard);

		return new RestfulResponse().ok(payload);
	}
	
	@GET
	@Path("/reports")
	public Response getDashboardReport(@BeanParam DashboardReportRequest dashboardReportRequest){
		List<Report> reports = dashboardService.fetchDashboardReport(dashboardReportRequest);

		Payload payload = new Payload();
		payload.put("reports", reports);

		return new RestfulResponse().ok(payload);
	}

}
