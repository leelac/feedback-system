package com.cognizant.hackfse.service;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.builder.EmailContentBuilder;
import com.cognizant.hackfse.model.Email;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmailService {

	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private EmailContentBuilder emailContentBuilder;

	@Value("${hackfse.feedback.from.email.address:hackfase@test.com}")
	private String fromEmailAddress;
	
	@Value("${hackfse.feedback.email.subject:Outreach Survey}")
	private String emailSubject;

	public void sendEmail(Email email) throws MessagingException {
		MimeMessagePreparator messagePreparator = mimeMessage -> {
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
			messageHelper.setFrom(fromEmailAddress);
			messageHelper.setTo(email.getEmailAddress());
			messageHelper.setSubject(emailSubject);
			String content = emailContentBuilder.build(email);
			messageHelper.setText(content, true);
		};
		try {
			javaMailSender.send(messagePreparator);
		} catch (MailException e) {
			log.info("Exception while sending an email : "+e);
		}
	}
}
