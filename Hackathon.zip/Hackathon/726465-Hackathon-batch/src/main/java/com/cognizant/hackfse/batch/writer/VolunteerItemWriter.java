package com.cognizant.hackfse.batch.writer;

import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.client.EmailClient;
import com.cognizant.hackfse.batch.entity.Event;
import com.cognizant.hackfse.batch.model.Email;
import com.cognizant.hackfse.batch.repository.EventRepository;

@Configuration
public class VolunteerItemWriter implements ItemWriter<Event> {

	@Autowired
	EventRepository eventRepository;


	@Autowired
	EmailClient emailClient;

	@Value("${email.url}")
	private String uri;
	@Override
	public void write(List<? extends Event> events) throws Exception {

		events.stream().map(event -> getandUpdateEvent(event)).collect(Collectors.toList());

	}

	private Event getandUpdateEvent(Event event) {
		Event eventRecordfromDB = eventRepository.findByEmployeeEvent(event.getEmployeeEvent());
		eventRecordfromDB.setVolunteerStatus(event.getVolunteerStatus());
		
		Map<String, String> additionalOptions = new HashMap<>();
		additionalOptions.put("lastName", event.getEmployeeName());
		additionalOptions.put("eventName", event.getEventName());
		additionalOptions.put("beneficiaryName", event.getBeneficiaryName());
		additionalOptions.put("eventDate", event.getEventDate());
		String details = String.format("%s-%s-%s", event.getEmployeeEvent().getEmployeeID(), event.getEmployeeEvent().getEventID(), event.getEventDate());
		additionalOptions.put("encodedDetails", Base64.getEncoder().encodeToString(details.getBytes()));
		
		Email email = Email.builder()
				.emailType(event.getVolunteerStatus())
				.emailAddress(event.getEmail())
				.options(additionalOptions)
				.build();
		emailClient.sendEmail(email);
		return eventRecordfromDB;
	}

	
}
