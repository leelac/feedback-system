package com.cognizant.hackfse.batch.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeEvent implements Serializable {
	
	
	private static final long serialVersionUID = 6872735897193524024L;

	@Column(name = "eventID")
	private String eventID;

	@Column(name = "EmployeeID")
	private String employeeID;
	
}