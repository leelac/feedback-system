package com.cognizant.hackfse.batch.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.hackfse.batch.entity.EmployeeEvent;
import com.cognizant.hackfse.batch.entity.Event;

public interface EventRepository extends CrudRepository<Event, Long> {
	
	Event findByEmployeeEvent(EmployeeEvent employeeEvent);
	
	

}
