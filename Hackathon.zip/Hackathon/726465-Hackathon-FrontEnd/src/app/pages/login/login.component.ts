import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": "Basic aGFja2ZzZTp0ZWNobm9nZWVrcw=="
  })

};
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm;

  constructor(private httpClient: HttpClient, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: [''],
      password: [''],
      grant_type: ['']
    });
  }

  login() {

    this.loginForm.controls['grant_type'].patchValue("password");

    const payload = new HttpParams()
      .set('username', this.loginForm.controls.username.value)
      .set('password', this.loginForm.controls.password.value)
      .set('grant_type', "password");

    this.httpClient.post("http://127.0.0.1:8092/oauth/token",
      payload, httpOptions)
      .subscribe(
      data => {
        this.router.navigateByUrl('/dashboard');
        console.log("POST Request is successful ", data);
      },
      error => {

        console.log("Error", error);

      }

      );

  }


}
