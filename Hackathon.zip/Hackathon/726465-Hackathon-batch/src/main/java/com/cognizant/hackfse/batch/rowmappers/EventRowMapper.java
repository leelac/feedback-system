package com.cognizant.hackfse.batch.rowmappers;

import org.springframework.batch.item.excel.RowMapper;
import org.springframework.batch.item.excel.support.rowset.RowSet;

import com.cognizant.hackfse.batch.configuration.VolunteerStatus;
import com.cognizant.hackfse.batch.entity.EmployeeEvent;
import com.cognizant.hackfse.batch.entity.Event;

public class EventRowMapper implements RowMapper<Event> {
	

	@Override
	public Event mapRow(RowSet event) throws Exception {
		

		return Event.builder().employeeEvent(EmployeeEvent.builder().eventID(event.getColumnValue(0))
				.employeeID(event.getColumnValue(7)).build())
				.baseLocation(event.getColumnValue(1))
				.beneficiaryName(event.getColumnValue(2))
				.councilName(event.getColumnValue(3))
				.eventName(event.getColumnValue(4))
				.eventDescription(event.getColumnValue(5))
				.eventDate(event.getColumnValue(6))
				.employeeName(event.getColumnValue(8))
				.volunteerHours(event.getColumnValue(9))
				.travelHours(event.getColumnValue(10))
				.livesImpacted(event.getColumnValue(11))
				.businessUnit(event.getColumnValue(12))
				.status(event.getColumnValue(13))
				.iiepCategory(event.getColumnValue(14))
				.volunteerStatus(VolunteerStatus.REGISTERED.toString())
				.build();
	}
	

}
