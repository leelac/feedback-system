package com.cognizant.hackfse.batch.listener;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomJobExecutionListener implements JobExecutionListener{
	

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("Batch Process Started!");
		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			log.info("Batch Process Completed!");

		}
		
	}

}
