package com.cognizant.hackfse.feedbackmanagement.exceptions;

public class AddressException extends Exception {

	private static final long serialVersionUID = -1957656509214618740L;
	
	public AddressException(String message) {
		super(message);
	}

}
