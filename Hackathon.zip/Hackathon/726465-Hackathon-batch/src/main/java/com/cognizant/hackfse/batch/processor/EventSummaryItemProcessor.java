package com.cognizant.hackfse.batch.processor;


import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.EventSummary;

@Configuration
public class EventSummaryItemProcessor implements ItemProcessor<EventSummary,EventSummary>{



	@Override
	public EventSummary process(EventSummary eventSummary) throws Exception {
		return eventSummary;
	}

}
