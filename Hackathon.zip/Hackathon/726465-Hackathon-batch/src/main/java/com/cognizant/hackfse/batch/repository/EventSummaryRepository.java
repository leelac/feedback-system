package com.cognizant.hackfse.batch.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.hackfse.batch.entity.EventSummary;

public interface EventSummaryRepository extends CrudRepository<EventSummary, Long> {
	
	

}
