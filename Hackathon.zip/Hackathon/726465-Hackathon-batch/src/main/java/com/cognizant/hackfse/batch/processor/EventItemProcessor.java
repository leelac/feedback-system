package com.cognizant.hackfse.batch.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Configuration;

import com.cognizant.hackfse.batch.entity.Event;

@Configuration
public class EventItemProcessor implements ItemProcessor<Event, Event> {

	@Override
	public Event process(Event item) throws Exception {

		return item;
	}

}
