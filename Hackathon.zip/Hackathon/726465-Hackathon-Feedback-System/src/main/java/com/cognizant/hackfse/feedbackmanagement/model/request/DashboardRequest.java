package com.cognizant.hackfse.feedbackmanagement.model.request;

import javax.ws.rs.QueryParam;

import lombok.Data;

@Data
public class DashboardRequest {

	@QueryParam("city")
	private String city;
	
	@QueryParam("beneficiary")
	private String beneficiary;
	
	@QueryParam("employeeId")
	private String employeeId;
	
	@QueryParam("role")
	private String role;
	
	@QueryParam("event")
	private String event;

}
