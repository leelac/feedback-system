package com.cognizant.hackfse.feedbackmanagement.exceptions;

public class FeedbackException extends Exception {

	private static final long serialVersionUID = -1957656509214618740L;
	
	public FeedbackException(String message) {
		super(message);
	}

}
