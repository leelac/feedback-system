import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { RestfulResponse } from '../models/restful-response.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private apiUrl = 'http://localhost:9092/dashboard';
  
  constructor(private http:HttpClient) { }

  public getDashboardDetails(citySelected: any, beneficiarySelected: any, eventSelected: any){
    return this.http.get<RestfulResponse>(this.apiUrl, {
      params: {
        city: citySelected,
        beneficiary: beneficiarySelected,
        event: eventSelected,
        role: "ADMIN"
      }
    });
  }

  public getDashboardReport(citySelected: any, beneficiarySelected: any, startDate: any, endDate: any){
    return this.http.get<RestfulResponse>(this.apiUrl+"/reports", {
      params: {
        city: citySelected,
        beneficiary: beneficiarySelected,
        startDate: startDate,
        endDate: endDate
      }
    });
  }
}
