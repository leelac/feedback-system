package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class Report {
	private String label;
	private Double value;
}
