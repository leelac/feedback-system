export class RestfulResponse {
    status: string;
    data: any;
    errors: any;
    meta: any;
}
