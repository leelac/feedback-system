package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class City {
	private String name;
}
