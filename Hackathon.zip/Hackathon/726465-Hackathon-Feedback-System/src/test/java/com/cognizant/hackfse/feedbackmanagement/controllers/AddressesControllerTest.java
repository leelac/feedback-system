package com.cognizant.hackfse.feedbackmanagement.controllers;


import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.cognizant.hackfse.feedbackmanagement.exceptions.AddressException;
import com.cognizant.hackfse.feedbackmanagement.model.City;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.AddressesService;

@RunWith(MockitoJUnitRunner.class)
public class AddressesControllerTest {
	
	@Mock
	private AddressesService addressesService;
	
	private AddressesController addressesController;
	
	@Before
	public void setUp() {
		addressesController = new AddressesController(addressesService);
	}

	@Test
	public void should_get_countries_successfully() throws AddressException {
		List<String> countries = new ArrayList<>();
		countries.add("India");
		countries.add("Singapore");
		when(addressesService.getCountries("ADMIN", "310077")).thenReturn(countries);
		
		Response response = addressesController.getCountries("ADMIN", "310077");
		
		assertThat(response.getStatus(), is(200));
	}
	
	@Test
	public void should_get_cities_successfully() throws AddressException {
		List<String> cities = new ArrayList<>();
		cities.add("Chennai");
		when(addressesService.getCities("India")).thenReturn(cities);
		
		Response response = addressesController.getCities("India");
		
		RestfulResponse restfulResponse = (RestfulResponse) response.getEntity();
		
		List<City> citiesResponse = new ArrayList<>();
		City city = new City();
		city.setName("Chennai");
		citiesResponse.add(city);
		
		assertThat(response.getStatus(), is(200));
		assertThat(restfulResponse.getData().get("cities"), is(citiesResponse));
	}
}
