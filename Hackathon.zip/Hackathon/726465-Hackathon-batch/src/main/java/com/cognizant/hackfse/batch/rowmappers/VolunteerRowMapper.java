package com.cognizant.hackfse.batch.rowmappers;

import org.springframework.batch.item.excel.RowMapper;
import org.springframework.batch.item.excel.support.rowset.RowSet;

import com.cognizant.hackfse.batch.entity.EmployeeEvent;
import com.cognizant.hackfse.batch.entity.Event;

public class VolunteerRowMapper implements RowMapper<Event> {

	private String status = "";

	public VolunteerRowMapper(String status) {
		this.status = status;
	}

	@Override
	public Event mapRow(RowSet event) throws Exception {

		return Event.builder()
				.employeeEvent(EmployeeEvent.builder().eventID(event.getColumnValue(0))
						.employeeID(event.getColumnValue(5)).build())
				.baseLocation(event.getColumnValue(3)).beneficiaryName(event.getColumnValue(2))
				.eventName(event.getColumnValue(1)).eventDate(event.getColumnValue(4))
				.volunteerStatus(status).build();
	}

}
