package com.cognizant.hackfse.feedbackmanagement.rest;

import lombok.Data;

@Data
public class Violation {
    private String code;
    private String message;
}
