package com.cognizant.hackfse.feedbackmanagement.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import com.cognizant.hackfse.feedbackmanagement.model.Violation;

public class AddressExceptionMapper implements ExceptionMapper<AddressException> {

	@Override
	public Response toResponse(AddressException exception) {
		Violation violation = new Violation();
		violation.setMessage(exception.getMessage());
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(violation).type(MediaType.APPLICATION_JSON).build();
	}

}
