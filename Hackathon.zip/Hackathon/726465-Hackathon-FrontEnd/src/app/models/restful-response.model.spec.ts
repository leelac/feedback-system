import { RestfulResponse } from './restful-response.model';

describe('RestfulResponse', () => {
  it('should create an instance', () => {
    expect(new RestfulResponse()).toBeTruthy();
  });
});
