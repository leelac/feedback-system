package com.cognizant.hackfse.feedbackmanagement.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.hackfse.feedbackmanagement.model.Beneficiary;
import com.cognizant.hackfse.feedbackmanagement.model.Event;
import com.cognizant.hackfse.feedbackmanagement.rest.Payload;
import com.cognizant.hackfse.feedbackmanagement.rest.RestfulResponse;
import com.cognizant.hackfse.feedbackmanagement.service.BeneficiaryService;

@Path("/benificiaries")
@Produces("application/json")
public class BeneficiaryController {

	@Autowired
	private BeneficiaryService beneficiaryService;

	@GET
	public Response getBeneficiaries(@QueryParam("city") String city, @QueryParam("role") String role,
			@QueryParam("employeeId") String employeeId) {
		List<String> beneficiaries = beneficiaryService.getBeneficiaries(city, role, employeeId);

		Payload payload = new Payload();
		payload.put("beneficiaries", beneficiariesFor(beneficiaries));

		return new RestfulResponse().ok(payload);		
	}

	@GET
	@Path("/events")
	public Response getEventsForBeneficiaries(@QueryParam("city") String city, @QueryParam("role") String role,
			@QueryParam("employeeId") String employeeId, @QueryParam("beneficiary") String beneficiary) {
		List<String> events = beneficiaryService.getEventsForBeneficiaries(city, role, employeeId, beneficiary);
		
		Payload payload = new Payload();
		payload.put("events", eventsFor(events));

		return new RestfulResponse().ok(payload);
	}

	private List<Beneficiary> beneficiariesFor(List<String> beneficiaries) {
		return beneficiaries.stream().map(bene -> {
			Beneficiary beneficiary = new Beneficiary();
			beneficiary.setName(bene);
			return beneficiary;
		}).collect(Collectors.toList());
	}
	

	private List<Event> eventsFor(List<String> events) {
		return events.stream().map(eve -> {
			Event event = new Event();
			event.setName(eve);
			return event;
		}).collect(Collectors.toList());
	}

}
