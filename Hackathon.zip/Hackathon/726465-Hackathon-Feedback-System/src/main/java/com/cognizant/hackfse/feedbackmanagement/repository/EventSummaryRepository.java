package com.cognizant.hackfse.feedbackmanagement.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.hackfse.feedbackmanagement.entity.EventSummary;

public interface EventSummaryRepository extends CrudRepository<EventSummary, Long> {

	List<EventSummary> findAllByOrderByBaseLocationAsc();

	List<EventSummary> findByPmoIDOrderByBaseLocationAsc(String pmoId);

	List<EventSummary> findByPocIDOrderByBaseLocationAsc(String pocId);

	List<EventSummary> findByBaseLocationOrderByVenueAddressAsc(String baseLocation);

	List<EventSummary> findByVenueAddressOrderByBeneficiaryNameAsc(String venueAddress);

	List<EventSummary> findByVenueAddressAndPmoIDOrderByBeneficiaryNameAsc(String venueAddress, String pmoId);

	List<EventSummary> findByVenueAddressAndPocIDOrderByBeneficiaryNameAsc(String venueAddress, String pocId);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameOrderByEventDateAsc(String venueAddress,
			String beneficiaryName);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameAndPmoIDOrderByEventDateAsc(String venueAddress,
			String beneficiaryName, String pmoId);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameAndPocIDOrderByEventDateAsc(String venueAddress,
			String beneficiaryName, String pocId);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameAndEventName(String venueAddress,
			String beneficiaryName, String eventName);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameAndEventNameAndPmoID(String venueAddress,
			String beneficiaryName, String pmoId, String eventName);

	List<EventSummary> findByVenueAddressAndBeneficiaryNameAndEventNameAndPocID(String venueAddress,
			String beneficiaryName, String pocId, String eventName);
}
