package com.cognizant.hackfse.feedbackmanagement.model;

import lombok.Data;

@Data
public class EmployeeEvent {
	
	private String eventName;
	private String employeeId;
	private String employeeName;
	private String businessUnit;
	private String feedbackProvided;
	private String feedbackDetails;

}
