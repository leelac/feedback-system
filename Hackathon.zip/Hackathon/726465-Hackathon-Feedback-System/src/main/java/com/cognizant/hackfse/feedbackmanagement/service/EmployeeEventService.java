package com.cognizant.hackfse.feedbackmanagement.service;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.BadRequestException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.feedbackmanagement.entity.Event;
import com.cognizant.hackfse.feedbackmanagement.entity.EventSummary;
import com.cognizant.hackfse.feedbackmanagement.model.EmployeeEvent;
import com.cognizant.hackfse.feedbackmanagement.model.request.EmployeeEventRequest;
import com.cognizant.hackfse.feedbackmanagement.repository.EventRepository;
import com.cognizant.hackfse.feedbackmanagement.repository.EventSummaryRepository;
import com.cognizant.hackfse.feedbackmanagement.service.AddressesService.Roles;

@Service
public class EmployeeEventService {
	
	@Autowired
	private EventSummaryRepository eventSummaryRepository;

	@Autowired
	private EventRepository eventRepository;

	public List<EmployeeEvent> fetchEmployeeEventDetails(EmployeeEventRequest employeeEventRequest) {

		List<EventSummary> eventSummaries = null;

		if (Roles.ADMIN.name().equalsIgnoreCase(employeeEventRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventName(
					employeeEventRequest.getCity(), employeeEventRequest.getBeneficiary(),
					employeeEventRequest.getEvent());
		} else if (Roles.PMO.name().equalsIgnoreCase(employeeEventRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventNameAndPmoID(
					employeeEventRequest.getCity(), employeeEventRequest.getBeneficiary(),
					employeeEventRequest.getEmployeeId(), employeeEventRequest.getEvent());
		} else if (Roles.POC.name().equalsIgnoreCase(employeeEventRequest.getRole())) {
			eventSummaries = eventSummaryRepository.findByVenueAddressAndBeneficiaryNameAndEventNameAndPocID(
					employeeEventRequest.getCity(), employeeEventRequest.getBeneficiary(),
					employeeEventRequest.getEmployeeId(), employeeEventRequest.getEvent());
		}

		if (eventSummaries == null || eventSummaries.size() > 1) {
			throw new BadRequestException("Unable to fetch the details");
		}

		EventSummary eventSummary = eventSummaries.get(0);

		List<Event> events = eventRepository.findByEventId(eventSummary.getEventID());

		List<EmployeeEvent> employeeEvents = new ArrayList<>();

		events.stream().forEach(eve -> {
			EmployeeEvent employeeEvent = new EmployeeEvent();
			employeeEvent.setEventName(eve.getEventName());
			employeeEvent.setEmployeeId(eve.getEmployeeEvent().getEmployeeID());
			employeeEvent.setEmployeeName(eve.getEmployeeName());
			employeeEvent.setBusinessUnit(eve.getBusinessUnit());
			employeeEvent.setFeedbackProvided(eve.getFeedbackRating() != null ? "Yes" : "No");
			employeeEvent.setFeedbackDetails(eve.getFeedbackDetails());
			employeeEvents.add(employeeEvent);
		});

		return employeeEvents;
	}
}
