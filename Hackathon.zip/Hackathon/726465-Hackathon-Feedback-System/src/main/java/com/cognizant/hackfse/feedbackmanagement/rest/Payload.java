package com.cognizant.hackfse.feedbackmanagement.rest;

import java.util.HashMap;

public final class Payload extends HashMap<String, Object> {

    private static final long serialVersionUID = 1L;

}
