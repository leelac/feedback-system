package com.cognizant.hackfse.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.hackfse.entity.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback, Long>{
	
	Feedback findbyTemplateName(String templateName);

}
