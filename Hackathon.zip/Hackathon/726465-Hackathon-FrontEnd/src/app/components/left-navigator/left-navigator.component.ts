import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-navigator',
  templateUrl: './left-navigator.component.html',
  styleUrls: ['./left-navigator.component.scss']
})
export class LeftNavigatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
