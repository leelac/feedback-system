package com.cognizant.hackfse.model;

import java.util.Map;

import lombok.Data;

@Data
public class Email {

	private String emailAddress;
	private String emailType;
	private Map<String, String> options;
	
}
